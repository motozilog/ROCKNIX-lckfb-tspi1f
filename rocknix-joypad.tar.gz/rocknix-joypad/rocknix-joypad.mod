./rocknix-joypad.o
