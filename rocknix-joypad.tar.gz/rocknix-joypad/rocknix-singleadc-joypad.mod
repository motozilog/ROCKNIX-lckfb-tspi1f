./rocknix-singleadc-joypad.o
